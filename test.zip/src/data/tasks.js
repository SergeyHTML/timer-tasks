export const tasks = [
  {
    id: 1,
    name: 'Task 1',
    time: '900',
    status: 'create',
  },
  {
    id: 2,
    name: 'Task 2',
    time: '70000',
    status: 'create',
  },
  {
    id: 3,
    name: 'Task 3',
    time: '1900',
    status: 'create',
  },
  {
    id: 4,
    name: 'Task 4',
    time: '50',
    status: 'finished',
  }

]