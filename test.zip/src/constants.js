export const CURRENT_TASK = 'CURRENT_TASK';

export const DELETE_TASK = 'DELETE_TASK';

export const CHANGE_STATUS = 'CHANGE_STATUS';

export const ADD_TASK = 'ADD_TASK';

export const START_TIMER = 'START_TIMER';